-- עדכון טבלת products עם השדות החסרים
-- הרץ זאת אם טבלת products כבר קיימת ואתה רוצה להוסיף את השדות החדשים

USE quickshop5;

-- הוספת שדות חדשים לטבלת products אם הם לא קיימים
SET @table_name = 'products';

-- בדיקה והוספת שדה barcode
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'barcode';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN barcode VARCHAR(100) AFTER sku',
    'SELECT "Column barcode already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- בדיקה והוספת שדה vendor
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'vendor';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN vendor VARCHAR(255) AFTER is_digital',
    'SELECT "Column vendor already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- בדיקה והוספת שדה product_type
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'product_type';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN product_type VARCHAR(100) AFTER vendor',
    'SELECT "Column product_type already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- בדיקה והוספת שדה tags
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'tags';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN tags TEXT AFTER product_type',
    'SELECT "Column tags already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- בדיקה והוספת שדה has_variants
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'has_variants';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN has_variants BOOLEAN DEFAULT FALSE AFTER featured',
    'SELECT "Column has_variants already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- בדיקה והוספת שדה seo_keywords
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = @table_name 
AND column_name = 'seo_keywords';

SET @sql = IF(@column_exists = 0, 
    'ALTER TABLE products ADD COLUMN seo_keywords TEXT AFTER seo_description',
    'SELECT "Column seo_keywords already exists" as message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- הוספת אינדקסים חדשים
CREATE INDEX IF NOT EXISTS idx_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_vendor ON products(vendor);
CREATE INDEX IF NOT EXISTS idx_product_type ON products(product_type);

-- הצגת מבנה הטבלה המעודכן
DESCRIBE products; 