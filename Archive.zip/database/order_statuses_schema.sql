-- טבלת סטטוסי הזמנות מותאמים אישית
CREATE TABLE IF NOT EXISTS order_statuses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL DEFAULT 1,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    color VARCHAR(7) NOT NULL DEFAULT '#6B7280', -- צבע הקס
    background_color VARCHAR(7) NOT NULL DEFAULT '#F3F4F6', -- צבע רקע
    icon VARCHAR(50) DEFAULT 'ri-circle-line', -- אייקון Remix
    is_default BOOLEAN DEFAULT FALSE, -- האם זה סטטוס ברירת מחדל
    is_system BOOLEAN DEFAULT FALSE, -- האם זה סטטוס מערכת (לא ניתן למחיקה)
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    
    -- הגדרות התנהגות
    allow_edit BOOLEAN DEFAULT TRUE, -- האם ניתן לערוך הזמנות בסטטוס זה
    auto_complete_payment BOOLEAN DEFAULT FALSE, -- האם להשלים תשלום אוטומטית
    send_email_notification BOOLEAN DEFAULT TRUE, -- האם לשלוח התראה למייל
    send_sms_notification BOOLEAN DEFAULT FALSE, -- האם לשלוח SMS
    
    -- הגדרות מלאי
    reduce_stock BOOLEAN DEFAULT FALSE, -- האם להוריד מהמלאי
    release_stock BOOLEAN DEFAULT FALSE, -- האם לשחרר מלאי חזרה
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_order_store_slug (store_id, slug),
    INDEX idx_order_store_active (store_id, is_active),
    INDEX idx_order_sort_order (sort_order),
    INDEX idx_order_system (is_system)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- טבלת סטטוסי תשלום מותאמים אישית
CREATE TABLE IF NOT EXISTS payment_statuses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL DEFAULT 1,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    color VARCHAR(7) NOT NULL DEFAULT '#6B7280',
    background_color VARCHAR(7) NOT NULL DEFAULT '#F3F4F6',
    icon VARCHAR(50) DEFAULT 'ri-money-dollar-circle-line',
    is_default BOOLEAN DEFAULT FALSE,
    is_system BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    
    -- הגדרות התנהגות
    is_paid BOOLEAN DEFAULT FALSE, -- האם הסטטוס מסמן תשלום מושלם
    allow_refund BOOLEAN DEFAULT FALSE, -- האם ניתן להחזיר כסף
    auto_fulfill BOOLEAN DEFAULT FALSE, -- האם לבצע מילוי אוטומטי
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_payment_store_slug (store_id, slug),
    INDEX idx_payment_store_active (store_id, is_active),
    INDEX idx_payment_sort_order (sort_order),
    INDEX idx_payment_system (is_system)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הוספת סטטוסי ברירת מחדל לכל חנות חדשה
-- זה ירוץ בטריגר כשחנות נוצרת

-- עדכון טבלת הזמנות להשתמש בסטטוסים המותאמים
ALTER TABLE orders 
ADD COLUMN order_status_id INT NULL AFTER status,
ADD COLUMN payment_status_id INT NULL AFTER payment_status,
ADD FOREIGN KEY (order_status_id) REFERENCES order_statuses(id) ON DELETE SET NULL,
ADD FOREIGN KEY (payment_status_id) REFERENCES payment_statuses(id) ON DELETE SET NULL;

-- אינדקסים נוספים
CREATE INDEX idx_order_status ON orders(order_status_id);
CREATE INDEX idx_payment_status ON orders(payment_status_id); 