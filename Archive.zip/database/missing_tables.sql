-- טבלאות חסרות למערכת ההגדרות של QuickShop5

-- הגדרות הטמעות פיקסלים (אנליטיקס)
CREATE TABLE IF NOT EXISTS analytics_pixels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    pixel_type ENUM('google_analytics', 'facebook_pixel', 'google_ads', 'tiktok_pixel', 'custom') NOT NULL,
    name VARCHAR(255) NOT NULL,
    pixel_id VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_type (store_id, pixel_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות תשלום (ספקי תשלום)
CREATE TABLE IF NOT EXISTS payment_providers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    provider_name ENUM('paypal', 'stripe', 'credit_guard', 'tranzila', 'bit', 'cash_on_delivery', 'bank_transfer') NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT FALSE,
    is_test_mode BOOLEAN DEFAULT TRUE,
    settings JSON, -- הגדרות ספציפיות לכל ספק
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_provider (store_id, provider_name),
    INDEX idx_store_active (store_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות משלוח (אזורים ושיטות משלוח)
CREATE TABLE IF NOT EXISTS shipping_zones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    countries JSON, -- רשימת מדינות
    states JSON, -- רשימת מחוזות/אזורים
    postcodes JSON, -- מיקודים
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_active (store_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS shipping_methods (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    zone_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    method_type ENUM('flat_rate', 'free_shipping', 'local_pickup', 'calculated') DEFAULT 'flat_rate',
    cost DECIMAL(10,2) DEFAULT 0,
    min_order_amount DECIMAL(10,2),
    max_weight DECIMAL(8,2),
    estimated_delivery_days INT,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES shipping_zones(id) ON DELETE CASCADE,
    INDEX idx_zone_active (zone_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות התראות
CREATE TABLE IF NOT EXISTS notification_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    notification_type ENUM('new_order', 'low_stock', 'order_shipped', 'payment_received', 'customer_registered') NOT NULL,
    is_enabled BOOLEAN DEFAULT TRUE,
    email_enabled BOOLEAN DEFAULT TRUE,
    sms_enabled BOOLEAN DEFAULT FALSE,
    slack_enabled BOOLEAN DEFAULT FALSE,
    webhook_enabled BOOLEAN DEFAULT FALSE,
    recipients JSON, -- רשימת נמענים
    settings JSON, -- הגדרות נוספות
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_notification (store_id, notification_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- אקורדיונים גלובליים (לכל המוצרים)
CREATE TABLE IF NOT EXISTS global_accordions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    icon VARCHAR(50),
    is_open_by_default BOOLEAN DEFAULT FALSE,
    apply_to_all_products BOOLEAN DEFAULT TRUE,
    category_ids JSON, -- אם לא לכל המוצרים
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_active (store_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- קודי מעקב (פיקסלים וסקריפטים)
CREATE TABLE IF NOT EXISTS tracking_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    code_type ENUM('header', 'footer', 'body_start', 'body_end', 'order_confirmation') NOT NULL,
    code_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_type (store_id, code_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות SMS
CREATE TABLE IF NOT EXISTS sms_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    provider ENUM('twilio', 'nexmo', 'clicksend', 'infobip') DEFAULT 'twilio',
    api_key VARCHAR(255),
    api_secret VARCHAR(255),
    sender_name VARCHAR(20),
    is_active BOOLEAN DEFAULT FALSE,
    test_mode BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_sms (store_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- שיתוף גישה (גישה לאנשים נוספים)
CREATE TABLE IF NOT EXISTS store_access (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    email VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'viewer', 'editor') DEFAULT 'viewer',
    permissions JSON, -- הרשאות ספציפיות
    is_active BOOLEAN DEFAULT TRUE,
    invited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    accepted_at TIMESTAMP NULL,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_email (store_id, email),
    INDEX idx_store_role (store_id, role),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- חיובי מערכת (מעקב חיובים ועמלות)
CREATE TABLE IF NOT EXISTS system_billings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    billing_type ENUM('subscription', 'commission', 'transaction_fee', 'addon') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    vat_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    billing_period_start DATE,
    billing_period_end DATE,
    status ENUM('pending', 'paid', 'overdue', 'cancelled') DEFAULT 'pending',
    due_date DATE,
    paid_at TIMESTAMP NULL,
    invoice_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_period (store_id, billing_period_start, billing_period_end),
    INDEX idx_status_due (status, due_date),
    INDEX idx_invoice (invoice_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- קוד מותאם אישית (CSS/JS)
CREATE TABLE IF NOT EXISTS custom_code (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    code_type ENUM('css', 'javascript', 'html') NOT NULL,
    position ENUM('header', 'footer', 'before_body_end') DEFAULT 'header',
    code_content TEXT NOT NULL,
    name VARCHAR(255),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_type (store_id, code_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות עוגיות (GDPR)
CREATE TABLE IF NOT EXISTS gdpr_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    cookie_banner_enabled BOOLEAN DEFAULT TRUE,
    banner_text TEXT,
    banner_button_text VARCHAR(100) DEFAULT 'אני מסכים',
    privacy_policy_url VARCHAR(500),
    terms_of_service_url VARCHAR(500),
    data_retention_days INT DEFAULT 365,
    allow_analytics BOOLEAN DEFAULT TRUE,
    allow_marketing BOOLEAN DEFAULT FALSE,
    allow_functional BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_gdpr (store_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- API מפתחות
CREATE TABLE IF NOT EXISTS api_keys (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    key_name VARCHAR(255) NOT NULL,
    api_key VARCHAR(255) NOT NULL UNIQUE,
    api_secret VARCHAR(255),
    permissions JSON, -- הרשאות (read, write, products, orders וכו')
    rate_limit_per_hour INT DEFAULT 1000,
    last_used_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_active (store_id, is_active),
    INDEX idx_api_key (api_key),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- חברות משלוח
CREATE TABLE IF NOT EXISTS shipping_companies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    company_name ENUM('israel_post', 'ups', 'fedex', 'dhl', 'aramex', 'get', 'wolt', 'custom') NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    api_credentials JSON, -- מפתחות API
    default_service VARCHAR(100),
    is_active BOOLEAN DEFAULT FALSE,
    settings JSON, -- הגדרות נוספות
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_company (store_id, company_name),
    INDEX idx_store_active (store_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- דומיינים מותאמים אישית
CREATE TABLE IF NOT EXISTS custom_domains (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    domain_name VARCHAR(255) NOT NULL UNIQUE,
    ssl_certificate TEXT,
    ssl_private_key TEXT,
    verification_token VARCHAR(255),
    status ENUM('pending', 'verified', 'active', 'failed') DEFAULT 'pending',
    dns_records JSON, -- רשומות DNS נדרשות
    last_verified_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_status (store_id, status),
    INDEX idx_domain (domain_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הגדרות אוטומציות (אחרי הזמנה)
CREATE TABLE IF NOT EXISTS automations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    trigger_event ENUM('order_placed', 'order_paid', 'order_shipped', 'order_delivered', 'abandoned_cart', 'customer_registered') NOT NULL,
    conditions JSON, -- תנאים להפעלה
    actions JSON, -- פעולות לביצוע
    delay_minutes INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    run_count INT DEFAULT 0,
    last_run_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_trigger (store_id, trigger_event),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; 