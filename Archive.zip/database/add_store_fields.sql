-- הוספת שדות נדרשים לטבלת stores
ALTER TABLE stores 
ADD COLUMN slug VARCHAR(100) UNIQUE NOT NULL AFTER name,
ADD COLUMN custom_domain VARCHAR(255) NULL AFTER slug,
ADD COLUMN subdomain_enabled BOOLEAN DEFAULT TRUE AFTER custom_domain,
ADD COLUMN ssl_enabled BOOLEAN DEFAULT FALSE AFTER subdomain_enabled;

-- יצירת אינדקס לחיפוש מהיר
CREATE INDEX idx_stores_slug ON stores(slug);
CREATE INDEX idx_stores_custom_domain ON stores(custom_domain);

-- יצירת טבלת הגדרות חנות
CREATE TABLE IF NOT EXISTS store_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_setting (store_id, setting_key)
);

-- הוספת slugs לחנויות קיימות (אם יש)
UPDATE stores 
SET slug = LOWER(REPLACE(REPLACE(name, ' ', '-'), '--', '-'))
WHERE slug IS NULL OR slug = '';

-- וידוא יוניקיות
SET @counter = 0;
UPDATE stores s1 
JOIN (
    SELECT id, 
           ROW_NUMBER() OVER (PARTITION BY slug ORDER BY id) as rn
    FROM stores 
    WHERE slug IN (
        SELECT slug 
        FROM stores 
        GROUP BY slug 
        HAVING COUNT(*) > 1
    )
) s2 ON s1.id = s2.id
SET s1.slug = CONCAT(s1.slug, '-', s2.rn)
WHERE s2.rn > 1; 