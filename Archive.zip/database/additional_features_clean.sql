-- QuickShop5 Additional Features
-- אקורדיונים, שדות מותאמים אישית, upsell וcross-sell

-- טבלת אקורדיונים למוצרים (תיאור, מידת דוגמנית וכו')
CREATE TABLE product_accordions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    icon VARCHAR(50), -- remix icon class
    is_open_by_default BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_product_active (product_id, is_active),
    INDEX idx_sort (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- טבלת סוגי שדות מותאמים אישית (למחסן החנות)
CREATE TABLE custom_field_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    field_type ENUM('text', 'textarea', 'number', 'email', 'phone', 'url', 'date', 'datetime', 'time', 'select', 'multi_select', 'radio', 'checkbox', 'file', 'color') NOT NULL,
    label VARCHAR(255) NOT NULL,
    placeholder VARCHAR(255),
    is_required BOOLEAN DEFAULT FALSE,
    validation_rules JSON, -- אילוצי תקינות
    options JSON, -- אפשרויות לselect/radio וכו'
    help_text VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_type (store_id, field_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ערכי השדות המותאמים אישית לכל מוצר
CREATE TABLE product_custom_fields (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    field_type_id INT NOT NULL,
    field_value TEXT,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (field_type_id) REFERENCES custom_field_types(id) ON DELETE CASCADE,
    UNIQUE KEY unique_product_field (product_id, field_type_id),
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- קבוצות מוצרים משלימים/קשורים
CREATE TABLE product_collections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type ENUM('upsell', 'cross_sell', 'related', 'bundle', 'frequently_bought') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_type (store_id, type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- קישור מוצרים לקבוצות (many-to-many)
CREATE TABLE product_collection_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    collection_id INT NOT NULL,
    product_id INT NOT NULL,
    sort_order INT DEFAULT 0,
    discount_percentage DECIMAL(5,2) DEFAULT 0, -- הנחה במקרה של bundle
    is_required BOOLEAN DEFAULT FALSE, -- חובה במקרה של bundle
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (collection_id) REFERENCES product_collections(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_collection_product (collection_id, product_id),
    INDEX idx_collection (collection_id),
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- קישורי מוצרים ישירים (מוצר A מקושר למוצר B)
CREATE TABLE product_relationships (
    id INT PRIMARY KEY AUTO_INCREMENT,
    main_product_id INT NOT NULL,
    related_product_id INT NOT NULL,
    relationship_type ENUM('upsell', 'cross_sell', 'related', 'alternative', 'frequently_bought') NOT NULL,
    sort_order INT DEFAULT 0,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    is_automatic BOOLEAN DEFAULT FALSE, -- נוצר אוטומטית על בסיס התנהגות
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (main_product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (related_product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_product_relation (main_product_id, related_product_id, relationship_type),
    INDEX idx_main_product (main_product_id, relationship_type),
    INDEX idx_related_product (related_product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- חבילות מוצרים (bundles) עם תמחור מיוחד
CREATE TABLE product_bundles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    bundle_price DECIMAL(10,2),
    discount_type ENUM('fixed', 'percentage') DEFAULT 'percentage',
    discount_value DECIMAL(10,2) DEFAULT 0,
    min_items INT DEFAULT 1,
    max_items INT,
    is_active BOOLEAN DEFAULT TRUE,
    valid_from DATE,
    valid_until DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_active (store_id, is_active),
    INDEX idx_validity (valid_from, valid_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- מוצרים בחבילה
CREATE TABLE bundle_products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bundle_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    is_required BOOLEAN DEFAULT TRUE,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (bundle_id) REFERENCES product_bundles(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_bundle_product (bundle_id, product_id),
    INDEX idx_bundle (bundle_id),
    INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- הצעות upsell/cross-sell אוטומטיות
CREATE TABLE auto_suggestions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    store_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    trigger_type ENUM('cart_value', 'product_category', 'product_specific', 'customer_behavior') NOT NULL,
    trigger_condition JSON, -- תנאים מפורטים
    suggestion_type ENUM('upsell', 'cross_sell', 'bundle') NOT NULL,
    target_products JSON, -- רשימת מוצרים להצעה
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    max_suggestions INT DEFAULT 3,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_trigger (store_id, trigger_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; 